#include <unistd.h>
#include <sys/wait.h>
#include <sys/types.h>
#include "cmd.h"

int exec_commande(cmd* ma_cmd);